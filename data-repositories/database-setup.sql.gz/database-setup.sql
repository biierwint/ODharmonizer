-- login as "postgres"

CREATE DATABASE ohdsi
WITH ENCODING='UTF8'
        OWNER=postgres
        CONNECTION LIMIT=-1;
COMMENT ON DATABASE ohdsi
        IS 'ODmapper OMOP CDM database';
