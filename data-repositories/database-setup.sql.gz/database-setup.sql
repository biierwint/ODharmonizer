-- login as "postgres"

CREATE DATABASE odmapper
WITH ENCODING='UTF8'
        OWNER=postgres
        CONNECTION LIMIT=-1;
COMMENT ON DATABASE odmapper
        IS 'ODmapper OMOP CDM database';
